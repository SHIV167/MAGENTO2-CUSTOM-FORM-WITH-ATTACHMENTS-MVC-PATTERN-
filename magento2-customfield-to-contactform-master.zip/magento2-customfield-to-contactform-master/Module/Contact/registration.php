<?php
/**
 * Module_Contact module registration
 * @package Module\Contact
 */
declare(strict_types=1);

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Module_Contact',
    __DIR__
);
