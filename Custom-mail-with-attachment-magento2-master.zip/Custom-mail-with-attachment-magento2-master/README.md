Custom-mail-with-attachment-magento2

Add email id in admin section from store -> configration -> general -> store email addresses -> custom email 2

And submit form you will get mail with attachment.
