var config = {
    map: {
        '*': {
            myscript: 'Megha_UserForm/js/userform',
        }
    }
};
