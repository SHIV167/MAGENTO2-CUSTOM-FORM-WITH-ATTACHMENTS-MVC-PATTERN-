<?php

namespace Megha\UserForm\Block;

use Magento\Framework\View\Element\Template;

class User extends Template
{
    public function getMyText()
    {
        return "Hii..!";
    }
}
