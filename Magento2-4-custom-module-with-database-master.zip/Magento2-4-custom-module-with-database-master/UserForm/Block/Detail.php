<?php


namespace Megha\UserForm\Block;


use Magento\Framework\View\Element\Template;

class Detail extends Template
{

}
