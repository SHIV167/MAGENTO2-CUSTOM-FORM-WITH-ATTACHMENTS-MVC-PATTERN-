<?php

namespace Megha\UserForm\Api\Data;

interface UserFormInterface
{

    /**
     * @return int|null
     */
    public function getId();
}
