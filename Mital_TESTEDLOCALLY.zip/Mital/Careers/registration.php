<?php
/**
 * Grid Module registration.
 * @category  Alps
 * @package   Alps_Careers
 * @author    Alps
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mital_Careers',
    __DIR__
);
