<h1 align="center">  
<br/>
  <img src="https://i.imgur.com/b2oclHA.png" alt="Custom Forms Frontend" width="400">  
  <br>  
  Alekseon_CustomFormsFrontend
  <br>  
</h1>  
<p align="center">
<strong>This module does not work separately.</strong>
<br>
<i>This is addon to <a href="https://github.com/Alekseon/magento2-custom-forms-builder">Alekseon_CustomFormsBuilder</a> module.</i>
<br>
<i>It is also a part of <a href="https://github.com/Alekseon/magento2-widget-forms">Alekseon_WidgetForms</a> module.</i>
<br>
</p>
<p>
This module is responsible for presenting custom forms data on frontend.
<br>
More in wiki:
<br>
<ul>
<li><a href="https://github.com/Alekseon/magento2-widget-forms/wiki">Widget Forms</a></li>
</ul>
</p>
